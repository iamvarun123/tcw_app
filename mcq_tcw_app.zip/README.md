MCQ TCW - Kivy App (ready to build)
==================================

This project contains a simple Kivy app that calculates MCQ scores using the 'tcw' logic.

Files:
- main.py           : The Kivy app source code
- buildozer.spec    : Template for Buildozer (edit as needed)
- requirements.txt  : Python package requirements
- icon.png          : Placeholder app icon

How to build APK (Linux / WSL):
1. Install system deps and python (Ubuntu example):
   sudo apt update && sudo apt install -y python3-pip python3-venv git zip unzip openjdk-17-jdk
2. Install buildozer:
   pip install --user buildozer
3. Initialize & build:
   cd project_folder
   buildozer init   # (will create/overwrite buildozer.spec, you can replace with the included one)
   # make sure 'requirements' includes 'kivy'
   buildozer -v android debug
4. The APK will be in bin/ directory after build finishes.

If you want me to attempt to build the APK for you, I cannot build native Android APKs in this environment.
But you can build locally using the steps above or use an online service (e.g., GitHub Actions + p4a) to produce the APK.

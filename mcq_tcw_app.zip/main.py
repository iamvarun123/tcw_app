    from kivy.app import App
    from kivy.uix.boxlayout import BoxLayout
    from kivy.uix.label import Label
    from kivy.uix.textinput import TextInput
    from kivy.uix.button import Button
    from kivy.core.window import Window

    Window.clearcolor = (1, 1, 1, 1)

    def calculate_score(total, correct, wrong):
        unattempted = total - (correct + wrong)
        attempted = correct + wrong

        # Scoring
        correct_marks = correct
        penalty = wrong * (-1/3)
        score = correct_marks + penalty
        percentage = (score / total) * 100 if total > 0 else 0
        accuracy = (correct / attempted * 100) if attempted > 0 else 0

        # Extrapolated
        factor = 200 / total if total>0 else 0
        extrap_correct = round(correct * factor)
        extrap_wrong = round(wrong * factor)
        extrap_unattempted = round(unattempted * factor)
        extrap_attempted = extrap_correct + extrap_wrong
        extrap_score = extrap_correct + extrap_wrong * (-1/3)
        extrap_accuracy = (extrap_correct / extrap_attempted * 100) if extrap_attempted > 0 else 0

        return dict(
            total=total, correct=correct, wrong=wrong, unattempted=unattempted,
            attempted=attempted, correct_marks=correct_marks, penalty=penalty,
            score=score, percentage=percentage, accuracy=accuracy,
            extrap_correct=extrap_correct, extrap_wrong=extrap_wrong,
            extrap_unattempted=extrap_unattempted, extrap_attempted=extrap_attempted,
            extrap_score=extrap_score, extrap_accuracy=extrap_accuracy
        )

    class MCQCalculator(BoxLayout):
        def __init__(self, **kwargs):
            super().__init__(orientation='vertical', padding=12, spacing=10, **kwargs)

            self.title = Label(text='MCQ Score Calculator (tcw)', size_hint=(1, 0.12), bold=True, color=(0,0,0,1))
            self.add_widget(self.title)

            self.total_input = TextInput(hint_text='Total Questions', input_filter='int', multiline=False, size_hint=(1, None), height=44)
            self.correct_input = TextInput(hint_text='Correct Answers', input_filter='int', multiline=False, size_hint=(1, None), height=44)
            self.wrong_input = TextInput(hint_text='Wrong Answers', input_filter='int', multiline=False, size_hint=(1, None), height=44)

            self.calc_button = Button(text='Calculate', size_hint=(1, None), height=48)
            self.calc_button.bind(on_press=self.calculate)

            self.result_label = Label(text='Enter values and press Calculate', halign='left', valign='top', size_hint=(1, 1), color=(0,0,0,1))
            self.result_label.bind(size=self._update_text_size)

            self.add_widget(self.total_input)
            self.add_widget(self.correct_input)
            self.add_widget(self.wrong_input)
            self.add_widget(self.calc_button)
            self.add_widget(self.result_label)

        def _update_text_size(self, *args):
            self.result_label.text_size = (self.result_label.width, None)

        def calculate(self, instance):
            try:
                total = int(self.total_input.text)
                correct = int(self.correct_input.text)
                wrong = int(self.wrong_input.text)

                data = calculate_score(total, correct, wrong)

                result_text = (
                    f"""Total Questions: {data['total']}
Correct: {data['correct']}    Wrong: {data['wrong']}    Unattempted: {data['unattempted']}
Attempted: {data['attempted']}

Marks from Correct: {data['correct_marks']}
Penalty (Negative Marks): {data['penalty']:.2f}
Net Gain (Score): {data['score']:.2f}
Percentage: {data['percentage']:.2f}%
Attempt Accuracy: {data['accuracy']:.2f}%

--- Extrapolated to 200 Questions ---
Correct: {data['extrap_correct']}    Wrong: {data['extrap_wrong']}    Unattempted: {data['extrap_unattempted']}
Attempted: {data['extrap_attempted']}
Marks from Correct: {data['extrap_correct']}
Penalty (Negative Marks): {(data['extrap_wrong'] * -1/3):.2f}
Net Gain (Score): {data['extrap_score']:.2f}
Attempt Accuracy: {data['extrap_accuracy']:.2f}%"""
                )
                self.result_label.text = result_text
            except Exception as e:
                self.result_label.text = '❌ Please enter valid numbers for Total/Correct/Wrong'

    class MCQApp(App):
        def build(self):
            return MCQCalculator()

    if __name__ == '__main__':
        MCQApp().run()
